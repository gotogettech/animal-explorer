
# Ultimate Animal Explorer

Static educational web app.
See README in previous message for usage.
